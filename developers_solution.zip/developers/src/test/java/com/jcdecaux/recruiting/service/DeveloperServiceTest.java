package com.jcdecaux.recruiting.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.BDDMockito;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.jcdecaux.recruiting.model.Developer;
import com.jcdecaux.recruiting.repository.DeveloperRepository;
import com.jcdecaux.recruiting.service.DeveloperService;
import com.jcdecaux.recruiting.service.impl.DeveloperServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class DeveloperServiceTest {
	@Mock
	DeveloperRepository developerRepository;
	
	DeveloperService developerService;
	
	@Before
	public void setUp() {
		developerService = new DeveloperServiceImpl(developerRepository);
	}
	
	@Test
	public void createDeveloper() {
		Developer developer = new Developer();
		developer.setId(1L);
		developer.setFirstName("Thomas");
		developer.setLastName("Lebien");
		BDDMockito.given(developerRepository.save(ArgumentMatchers.any())).willReturn(developer);
		Developer developerResult = developerService.createDeveloper(developer);
		Assertions.assertThat(developerResult.getFirstName()).isEqualTo("Thomas");
		Assertions.assertThat(developerResult.getLastName()).isEqualTo("Lebien");

	}
	
	@Test
	public void getDeveloper() {
		Developer developer = new Developer();
		developer.setId(1L);
		developer.setFirstName("Thomas");
		developer.setLastName("Lebien");
		BDDMockito.given(developerRepository.findById(1L)).willReturn(Optional.of(developer));
		Developer developerResult = developerService.getDeveloper(1L).get();
		Assertions.assertThat(developerResult.getFirstName()).isEqualTo("Thomas");
		Assertions.assertThat(developerResult.getLastName()).isEqualTo("Lebien");
	
	}
    
	@Test
	public void getAllDevelopers() {
		List<Developer> developers = new ArrayList<>();
		Developer developer1 = new Developer();
		developer1.setId(1L);
		developer1.setFirstName("Thomas");
		developer1.setLastName("Lebien");
		developers.add(developer1);
		Developer developer2 = new Developer();
		developer2.setId(2L);
		developer2.setFirstName("François");
		developer2.setLastName("Dupont");
		developers.add(developer2);
		BDDMockito.given(developerRepository.findAll()).willReturn(developers);
		List<Developer> developerResult = developerService.getAllDevelopers();
		Assertions.assertThat(developerResult.size()).isEqualTo(2);
    }
}
