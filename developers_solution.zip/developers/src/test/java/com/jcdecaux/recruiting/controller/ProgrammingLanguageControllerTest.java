package com.jcdecaux.recruiting.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.BDDMockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jcdecaux.recruiting.controller.ProgrammingLanguageController;
import com.jcdecaux.recruiting.model.Developer;
import com.jcdecaux.recruiting.model.ProgrammingLanguage;
import com.jcdecaux.recruiting.service.DeveloperService;
import com.jcdecaux.recruiting.service.ProgrammingLanguageService;

@RunWith(SpringRunner.class)
@WebMvcTest(ProgrammingLanguageController.class)
public class ProgrammingLanguageControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@Autowired private ObjectMapper mapper;
	
	@MockBean
	private DeveloperService developerService;
	
	@MockBean
	ProgrammingLanguageService programmingLanguageService;
	
	@Test
	public void createProgrammingLanguage() throws Exception {
		ProgrammingLanguage programmingLanguage = new ProgrammingLanguage();
		programmingLanguage.setName("Java");
		
		String json = mapper.writeValueAsString(programmingLanguage);
		BDDMockito.given(programmingLanguageService.createProgrammingLanguage(ArgumentMatchers.any())).willReturn(programmingLanguage);

		mockMvc.perform(MockMvcRequestBuilders.post("/programmingLanguages").contentType(MediaType.APPLICATION_JSON)
			       .content(json))
		.andExpect(MockMvcResultMatchers.status().isOk())
		.andExpect(MockMvcResultMatchers.jsonPath("name").value("Java"));
			
		BDDMockito.verify(programmingLanguageService, BDDMockito.times(1)).createProgrammingLanguage(ArgumentMatchers.any());
		BDDMockito.verifyNoMoreInteractions(programmingLanguageService);
	}
	
	@Test
	public void getProgrammingLanguage() throws Exception {
		ProgrammingLanguage programmingLanguage = new ProgrammingLanguage();
		programmingLanguage.setId(1L);
		programmingLanguage.setName("Java");
		Optional<ProgrammingLanguage> oProgrammingLanguage = Optional.of(programmingLanguage);
		BDDMockito.given(programmingLanguageService.getProgrammingLanguage(1L)).willReturn(oProgrammingLanguage);

		mockMvc.perform(MockMvcRequestBuilders.get("/programmingLanguages/1"))
		.andExpect(MockMvcResultMatchers.status().isOk())
		.andExpect(MockMvcResultMatchers.jsonPath("name").value("Java"));
			
		BDDMockito.verify(programmingLanguageService, BDDMockito.times(1)).getProgrammingLanguage(1L);
		BDDMockito.verifyNoMoreInteractions(programmingLanguageService);
	}
	
	@Test
	public void getProgrammingLanguageFail() throws Exception {
		Optional<ProgrammingLanguage> oProgrammingLanguage = Optional.empty();
		BDDMockito.given(programmingLanguageService.getProgrammingLanguage(1L)).willReturn(oProgrammingLanguage);

		mockMvc.perform(MockMvcRequestBuilders.get("/programmingLanguages/1"))
		.andExpect(MockMvcResultMatchers.status().is(404));
			
		BDDMockito.verify(programmingLanguageService, BDDMockito.times(1)).getProgrammingLanguage(1L);
		BDDMockito.verifyNoMoreInteractions(programmingLanguageService);
	}
	
	@Test
	public void getAllProgrammingLanguages() throws Exception {
		List<ProgrammingLanguage> programmingLanguages = new ArrayList<>();
		ProgrammingLanguage programmingLanguage1 = new ProgrammingLanguage();
		programmingLanguage1.setId(1L);
		programmingLanguage1.setName("Java");
		programmingLanguages.add(programmingLanguage1);
		ProgrammingLanguage programmingLanguage2 = new ProgrammingLanguage();
		programmingLanguage2.setId(1L);
		programmingLanguage2.setName("Scala");
		programmingLanguages.add(programmingLanguage2);
		BDDMockito.given(programmingLanguageService.getAllProgrammingLanguages()).willReturn(programmingLanguages);

		mockMvc.perform(MockMvcRequestBuilders.get("/programmingLanguages"))
		.andExpect(MockMvcResultMatchers.status().isOk())
		.andExpect(MockMvcResultMatchers.jsonPath("$.length()").value(2))
		.andExpect(MockMvcResultMatchers.jsonPath("$[0].name").value("Java"))
		.andExpect(MockMvcResultMatchers.jsonPath("$[1].name").value("Scala"));
		
		BDDMockito.verify(programmingLanguageService, BDDMockito.times(1)).getAllProgrammingLanguages();
		BDDMockito.verifyNoMoreInteractions(programmingLanguageService);
	}

	@Test
	public void getDevelopersForAProgrammingLanguage() throws Exception {
		
		ProgrammingLanguage programmingLanguage = new ProgrammingLanguage();
		programmingLanguage.setId(1L);
		programmingLanguage.setName("Java");
		
		Developer developer = new Developer();
		developer.setId(1L);
		developer.setFirstName("Thomas");
		developer.setLastName("Lebien");
		developer.addProgrammingLanguage(programmingLanguage);
		Developer developer2 = new Developer();
		developer2.setId(2L);
		developer2.setFirstName("François");
		developer2.setLastName("Dupont");
		developer2.addProgrammingLanguage(programmingLanguage);
		Optional<ProgrammingLanguage> oProgrammingLanguage = Optional.of(programmingLanguage);
		BDDMockito.given(programmingLanguageService.getProgrammingLanguage(1L)).willReturn(oProgrammingLanguage);


		mockMvc.perform(MockMvcRequestBuilders.get("/programmingLanguages/1/developers"))
		.andExpect(MockMvcResultMatchers.status().isOk())
		.andExpect(MockMvcResultMatchers.jsonPath("$.length()").value(2));		
	}
}