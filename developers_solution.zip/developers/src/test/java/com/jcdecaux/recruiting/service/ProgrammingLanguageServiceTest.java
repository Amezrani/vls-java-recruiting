package com.jcdecaux.recruiting.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.BDDMockito;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.jcdecaux.recruiting.model.ProgrammingLanguage;
import com.jcdecaux.recruiting.repository.ProgrammingLanguageRepository;
import com.jcdecaux.recruiting.service.ProgrammingLanguageService;
import com.jcdecaux.recruiting.service.impl.ProgrammingLanguageServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class ProgrammingLanguageServiceTest {
	@Mock
	ProgrammingLanguageRepository programmingLanguageRepository;
	
	ProgrammingLanguageService programmingLanguageService;
	
	@Before
	public void setUp() {
		programmingLanguageService = new ProgrammingLanguageServiceImpl(programmingLanguageRepository);
	}
	
	@Test
	public void createProgrammingLanguage() {
		ProgrammingLanguage programmingLanguage = new ProgrammingLanguage();
		programmingLanguage.setId(1L);
		programmingLanguage.setName("Java");
		BDDMockito.given(programmingLanguageRepository.save(ArgumentMatchers.any())).willReturn(programmingLanguage);
		ProgrammingLanguage programmingLanguageResult = programmingLanguageService.createProgrammingLanguage(programmingLanguage);
		Assertions.assertThat(programmingLanguageResult.getName()).isEqualTo("Java");

	}
	
	@Test
	public void getProgrammingLanguage() {
		ProgrammingLanguage programmingLanguage = new ProgrammingLanguage();
		programmingLanguage.setId(1L);
		programmingLanguage.setName("Java");
		BDDMockito.given(programmingLanguageRepository.findById(1L)).willReturn(Optional.of(programmingLanguage));
		ProgrammingLanguage programmingLanguageResult = programmingLanguageService.getProgrammingLanguage(1L).get();
		Assertions.assertThat(programmingLanguageResult.getName()).isEqualTo("Java");
	
	}
    
	@Test
	public void getAllProgrammingLanguages() {
		List<ProgrammingLanguage> programmingLanguages = new ArrayList<>();
		ProgrammingLanguage programmingLanguage1 = new ProgrammingLanguage();
		programmingLanguage1.setId(1L);
		programmingLanguage1.setName("Java");
		programmingLanguages.add(programmingLanguage1);
		ProgrammingLanguage programmingLanguage2 = new ProgrammingLanguage();
		programmingLanguage2.setId(2L);
		programmingLanguage2.setName("Scala");
		programmingLanguages.add(programmingLanguage2);
		BDDMockito.given(programmingLanguageRepository.findAll()).willReturn(programmingLanguages);
		List<ProgrammingLanguage> programmingLanguageResult = programmingLanguageService.getAllProgrammingLanguages();
		Assertions.assertThat(programmingLanguageResult.size()).isEqualTo(2);
    }
}
