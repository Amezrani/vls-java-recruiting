package com.jcdecaux.recruiting.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.BDDMockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jcdecaux.recruiting.controller.DeveloperController;
import com.jcdecaux.recruiting.model.Developer;
import com.jcdecaux.recruiting.model.ProgrammingLanguage;
import com.jcdecaux.recruiting.service.DeveloperService;
import com.jcdecaux.recruiting.service.ProgrammingLanguageService;

@RunWith(SpringRunner.class)
@WebMvcTest(DeveloperController.class)
public class DeveloperControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@Autowired private ObjectMapper mapper;
	
	@MockBean
	private DeveloperService developerService;
	
	@MockBean
	ProgrammingLanguageService programmingLanguageService;
	
	@Test
	public void createDeveloper() throws Exception {
		Developer developer = new Developer();
		developer.setFirstName("Thomas");
		developer.setLastName("Lebien");		
		String json = mapper.writeValueAsString(developer);
		BDDMockito.given(developerService.createDeveloper(ArgumentMatchers.any())).willReturn(developer);

		mockMvc.perform(MockMvcRequestBuilders.post("/developers").contentType(MediaType.APPLICATION_JSON)
			       .content(json))
		.andExpect(MockMvcResultMatchers.status().isOk())
		.andExpect(MockMvcResultMatchers.jsonPath("firstName").value("Thomas"))
		.andExpect(MockMvcResultMatchers.jsonPath("lastName").value("Lebien"));
			
		BDDMockito.verify(developerService, BDDMockito.times(1)).createDeveloper(ArgumentMatchers.any());
		BDDMockito.verifyNoMoreInteractions(developerService);
	}
	
	@Test
	public void getDeveloper() throws Exception {
		Developer developer = new Developer();
		developer.setId(1L);
		developer.setFirstName("Thomas");
		developer.setLastName("Lebien");
		Optional<Developer> oDeveloper = Optional.of(developer);
		BDDMockito.given(developerService.getDeveloper(1L)).willReturn(oDeveloper);

		mockMvc.perform(MockMvcRequestBuilders.get("/developers/1"))
		.andExpect(MockMvcResultMatchers.status().isOk())
		.andExpect(MockMvcResultMatchers.jsonPath("firstName").value("Thomas"))
		.andExpect(MockMvcResultMatchers.jsonPath("lastName").value("Lebien"));
			
		BDDMockito.verify(developerService, BDDMockito.times(1)).getDeveloper(1L);
		BDDMockito.verifyNoMoreInteractions(developerService);
	}
	
	@Test
	public void getDeveloperFail() throws Exception {
		Optional<Developer> oDeveloper = Optional.empty();
		BDDMockito.given(developerService.getDeveloper(1L)).willReturn(oDeveloper);

		mockMvc.perform(MockMvcRequestBuilders.get("/developers/1"))
		.andExpect(MockMvcResultMatchers.status().is(404));
			
		BDDMockito.verify(developerService, BDDMockito.times(1)).getDeveloper(1L);
		BDDMockito.verifyNoMoreInteractions(developerService);
	}
	
	@Test
	public void getAllDevelopers() throws Exception {
		List<Developer> developers = new ArrayList<>();
		Developer developer1 = new Developer();
		developer1.setId(1L);
		developer1.setFirstName("Thomas");
		developer1.setLastName("Lebien");
		developers.add(developer1);
		Developer developer2 = new Developer();
		developer2.setId(2L);
		developer2.setFirstName("François");
		developer2.setLastName("Dupont");
		developers.add(developer2);
		BDDMockito.given(developerService.getAllDevelopers()).willReturn(developers);

		mockMvc.perform(MockMvcRequestBuilders.get("/developers"))
		.andExpect(MockMvcResultMatchers.status().isOk())
		.andExpect(MockMvcResultMatchers.jsonPath("$.length()").value(2))
		.andExpect(MockMvcResultMatchers.jsonPath("$[0].firstName").value("Thomas"))
		.andExpect(MockMvcResultMatchers.jsonPath("$[0].lastName").value("Lebien"))
		.andExpect(MockMvcResultMatchers.jsonPath("$[1].firstName").value("François"))
		.andExpect(MockMvcResultMatchers.jsonPath("$[1].lastName").value("Dupont"));
		
		BDDMockito.verify(developerService, BDDMockito.times(1)).getAllDevelopers();
		BDDMockito.verifyNoMoreInteractions(developerService);
	}

	@Test
	public void associateProgarmmingLanguageToDeveloper() throws Exception {
		Developer developer = new Developer();
		developer.setId(1L);
		developer.setFirstName("Thomas");
		developer.setLastName("Lebien");
		Optional<Developer> oDeveloper = Optional.of(developer);
		BDDMockito.given(developerService.getDeveloper(1L)).willReturn(oDeveloper);

		ProgrammingLanguage programmingLanguage = new ProgrammingLanguage();
		programmingLanguage.setId(1L);
		programmingLanguage.setName("Java");
		Optional<ProgrammingLanguage> oProgrammingLanguage = Optional.of(programmingLanguage);
		BDDMockito.given(programmingLanguageService.getProgrammingLanguage(1L)).willReturn(oProgrammingLanguage);

		
		mockMvc.perform(MockMvcRequestBuilders.put("/developers/1/associate/progarmmingLanguage/1"))
		.andExpect(MockMvcResultMatchers.status().isOk());
		Assertions.assertThat(developer.getProgrammingLanguages().size()).isEqualTo(1);
		Assertions.assertThat(programmingLanguage.getDevelopers().size()).isEqualTo(1);
		
	}
}