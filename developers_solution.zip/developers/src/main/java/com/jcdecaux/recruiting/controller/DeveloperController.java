package com.jcdecaux.recruiting.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jcdecaux.recruiting.exception.EntityNotFoundException;
import com.jcdecaux.recruiting.model.Developer;
import com.jcdecaux.recruiting.model.ProgrammingLanguage;
import com.jcdecaux.recruiting.service.DeveloperService;
import com.jcdecaux.recruiting.service.ProgrammingLanguageService;

@RestController
public class DeveloperController {

    @Autowired
    DeveloperService developerService;

    @Autowired
    ProgrammingLanguageService programmingLanguageService;

    @GetMapping("/developers")
    public List<Developer> getAllDevelopers() {
        return developerService.getAllDevelopers();
    }
    
    @GetMapping("/developers/{id}")
    public Developer getDeveloper(@PathVariable (value = "id") Long developerId) {
        return developerService.getDeveloper(developerId).
        		orElseThrow(() -> new EntityNotFoundException(String.format("Developer not found with id %s", developerId)));
    }

    @PostMapping("/developers")
    public Developer createDeveloper(@Valid @RequestBody Developer developer) {
       return developerService.createDeveloper(developer);
    }

    @PutMapping("/developers/{developerId}/associate/progarmmingLanguage/{programmingLanguageId}")
    public ResponseEntity<?> associateProgarmmingLanguageToDeveloper(@PathVariable (value = "developerId") Long developerId,
    		@PathVariable (value = "programmingLanguageId") Long programmingLanguageId) {
    	ProgrammingLanguage programmingLanguage = programmingLanguageService.getProgrammingLanguage(programmingLanguageId)
    			.orElseThrow(() -> new EntityNotFoundException(String.format("Programming Language not found with id %s", programmingLanguageId)));
        return developerService.getDeveloper(developerId).map(developer -> {
            developer.addProgrammingLanguage(programmingLanguage);
            developerService.createDeveloper(developer);
            return ResponseEntity.ok().build();
        }).orElseThrow(() -> new EntityNotFoundException(String.format("Developer not found with id %s", developerId)));
    }
}
