package com.jcdecaux.recruiting.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jcdecaux.recruiting.model.ProgrammingLanguage;
import com.jcdecaux.recruiting.repository.ProgrammingLanguageRepository;
import com.jcdecaux.recruiting.service.ProgrammingLanguageService;

@Service
public class ProgrammingLanguageServiceImpl implements ProgrammingLanguageService {

    
    ProgrammingLanguageRepository programmingLanguageRepository;

    @Autowired
    public ProgrammingLanguageServiceImpl(ProgrammingLanguageRepository programmingLanguageRepository) {
    	this.programmingLanguageRepository = programmingLanguageRepository;
	}

	public List<ProgrammingLanguage> getAllProgrammingLanguages() {
        return programmingLanguageRepository.findAll();
    }
    
    public Optional<ProgrammingLanguage> getProgrammingLanguage(Long programmingLanguageId) {
        return programmingLanguageRepository.findById(programmingLanguageId);
    }
    
    public ProgrammingLanguage createProgrammingLanguage(ProgrammingLanguage programmingLanguage) {
        return programmingLanguageRepository.save(programmingLanguage);
     }
}
