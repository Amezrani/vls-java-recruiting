package com.jcdecaux.recruiting.service;

import java.util.List;
import java.util.Optional;

import com.jcdecaux.recruiting.model.Developer;

public interface DeveloperService {

	public List<Developer> getAllDevelopers();
    
    public Optional<Developer> getDeveloper(Long developerId);
    
    public Developer createDeveloper(Developer developer);
}
