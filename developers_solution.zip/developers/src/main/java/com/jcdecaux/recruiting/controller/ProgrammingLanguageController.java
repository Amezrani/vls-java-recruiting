package com.jcdecaux.recruiting.controller;

import java.util.List;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jcdecaux.recruiting.exception.EntityNotFoundException;
import com.jcdecaux.recruiting.model.Developer;
import com.jcdecaux.recruiting.model.ProgrammingLanguage;
import com.jcdecaux.recruiting.service.ProgrammingLanguageService;

@RestController
public class ProgrammingLanguageController {

    @Autowired
    ProgrammingLanguageService programmingLanguageService;

    @GetMapping("/programmingLanguages")
    public List<ProgrammingLanguage> getAllProgrammingLanguages() {
        return programmingLanguageService.getAllProgrammingLanguages();
    }

    @GetMapping("/programmingLanguages/{id}")
    public ProgrammingLanguage getProgrammingLanguage(@PathVariable (value = "id") Long programmingLanguageId) {
        return programmingLanguageService.getProgrammingLanguage(programmingLanguageId)
        		.orElseThrow(() -> new EntityNotFoundException(String.format("Programming Language not found with id %s", programmingLanguageId)));
    }
    
    @PostMapping("/programmingLanguages")
    public ProgrammingLanguage createProgrammingLanguage(@Valid @RequestBody ProgrammingLanguage programmingLanguage) {
       return programmingLanguageService.createProgrammingLanguage(programmingLanguage);
    }

    @GetMapping("/programmingLanguages/{id}/developers")
    public Set<Developer> getDevelopersForAProgrammingLanguage(@PathVariable (value = "id") Long programmingLanguageId) {
    	return programmingLanguageService.getProgrammingLanguage(programmingLanguageId).map(programmingLanguage -> {
            return programmingLanguage.getDevelopers();
        }).orElseThrow(() -> new EntityNotFoundException(String.format("Programming Language not found with id %s", programmingLanguageId)));

    }
 
    
}
