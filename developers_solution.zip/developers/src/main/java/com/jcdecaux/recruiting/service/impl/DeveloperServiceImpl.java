package com.jcdecaux.recruiting.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jcdecaux.recruiting.model.Developer;
import com.jcdecaux.recruiting.repository.DeveloperRepository;
import com.jcdecaux.recruiting.service.DeveloperService;

@Service
public class DeveloperServiceImpl implements DeveloperService{

    
    DeveloperRepository developerRepository;
    
    @Autowired
    public DeveloperServiceImpl(DeveloperRepository developerRepository) {
		this.developerRepository = developerRepository;
	}

	public List<Developer> getAllDevelopers() {
        return developerRepository.findAll();
    }
    
    public Optional<Developer> getDeveloper(Long developerId) {
        return developerRepository.findById(developerId);
    }
    
    public Developer createDeveloper(Developer developer) {
        return developerRepository.save(developer);
    }
}
