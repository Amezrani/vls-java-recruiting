package com.jcdecaux.recruiting.service;

import java.util.List;
import java.util.Optional;

import com.jcdecaux.recruiting.model.ProgrammingLanguage;

public interface ProgrammingLanguageService {

    public List<ProgrammingLanguage> getAllProgrammingLanguages();
    
    public Optional<ProgrammingLanguage> getProgrammingLanguage(Long programmingLanguageId);
    
    public ProgrammingLanguage createProgrammingLanguage(ProgrammingLanguage programmingLanguage);
}
